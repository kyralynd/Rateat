<?php
// =====================================================
//  RateAt — Conexão com o banco de dados MySQL
// =====================================================
//  Ajuste as variáveis abaixo conforme seu ambiente:
//  - PC pessoal (XAMPP):  senha = ""
//  - Laboratório escolar: senha = "alunolab"
// =====================================================

$servidor = "localhost";
$porta     = "3307";      // Porta do MySQL no XAMPP (padrão: 3306 ou 3307)
$usuario   = "root";
$senha     = "";           // "" para PC pessoal  |  "alunolab" para laboratório
$banco     = "rateat";    // Nome do banco de dados

try {
    $conn = new PDO(
        "mysql:host=$servidor;port=$porta;dbname=$banco;charset=utf8",
        $usuario,
        $senha
    );
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // echo "Conectado com sucesso ao RateAt!";

} catch (PDOException $e) {
    die("Falha na conexão com o banco de dados: " . $e->getMessage());
}
?>
