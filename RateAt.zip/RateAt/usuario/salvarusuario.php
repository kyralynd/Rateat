<?php
// RateAt — Salvar novo usuário
include("../config/conexao.php");

$nome  = $_POST["nome"];
$email = $_POST["email"];
$senha = $_POST["senha"];

$sql = "INSERT INTO usuario (nome, email, senha) VALUES (:nome, :email, :senha)";
$stmt = $conn->prepare($sql);
$stmt->bindParam(":nome",  $nome);
$stmt->bindParam(":email", $email);
$stmt->bindParam(":senha", $senha);

if ($stmt->execute()) {
    echo "Usuário cadastrado com sucesso!";
    echo '<br><a href="../index.html">Voltar para a página inicial</a>';
} else {
    echo "Erro ao cadastrar usuário.";
}
?>
