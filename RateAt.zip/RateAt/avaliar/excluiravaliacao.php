<?php
// RateAt — Excluir avaliação
include("../config/conexao.php");

$id = (int) $_GET["id"];

$sql  = "DELETE FROM avaliacao WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->bindParam(":id", $id);

if ($stmt->execute()) {
    header("Location: listaravaliacao.php");
    exit;
} else {
    echo "Erro ao excluir avaliação.";
}
?>
