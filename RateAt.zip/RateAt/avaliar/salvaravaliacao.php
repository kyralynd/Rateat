<?php
// RateAt — Salvar avaliação
include("../config/conexao.php");

$nota            = (int) $_POST["nota"];
$comentario      = $_POST["comentario"];
$nome_restaurante = $_POST["nome_restaurante"];
// Em fase futura: pegar nome_usuario da sessão
$nome_usuario    = "Visitante";

$sql = "INSERT INTO avaliacao (nota, comentario, nome_usuario, nome_restaurante)
        VALUES (:nota, :comentario, :nome_usuario, :nome_restaurante)";

$stmt = $conn->prepare($sql);
$stmt->bindParam(":nota",             $nota);
$stmt->bindParam(":comentario",       $comentario);
$stmt->bindParam(":nome_usuario",     $nome_usuario);
$stmt->bindParam(":nome_restaurante", $nome_restaurante);

if ($stmt->execute()) {
    echo '<div style="font-family:sans-serif; padding:20px;">';
    echo '<p style="color:green; font-weight:bold;">✅ Avaliação enviada com sucesso!</p>';
    echo '<a href="../avaliar.html">← Fazer outra avaliação</a> &nbsp; ';
    echo '<a href="listaravaliacao.php">Ver todas as avaliações</a>';
    echo '</div>';
} else {
    echo "Erro ao salvar avaliação.";
}
?>
