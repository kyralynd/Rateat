<?php
// RateAt — Atualizar avaliação
include("../config/conexao.php");

$id         = (int) $_POST["id"];
$nota       = (int) $_POST["nota"];
$comentario = $_POST["comentario"];

$sql = "UPDATE avaliacao SET nota = :nota, comentario = :comentario WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->bindParam(":nota",       $nota);
$stmt->bindParam(":comentario", $comentario);
$stmt->bindParam(":id",         $id);
$stmt->execute();

header("Location: listaravaliacao.php");
exit;
?>
