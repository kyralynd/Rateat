<?php
// RateAt — Atualizar restaurante
include("../config/conexao.php");

$id        = (int) $_POST["id"];
$nome      = $_POST["nome"];
$cep       = $_POST["cep"];
$bairro    = $_POST["bairro"];
$rua       = $_POST["rua"];
$categoria = $_POST["categoria"];
$preco     = $_POST["preco"];
$descricao = $_POST["descricao"];

$sql = "UPDATE restaurante SET
        nome = :nome, cep = :cep, bairro = :bairro, rua = :rua,
        categoria = :categoria, preco = :preco, descricao = :descricao
        WHERE id = :id";

$stmt = $conn->prepare($sql);
$stmt->bindParam(":nome",      $nome);
$stmt->bindParam(":cep",       $cep);
$stmt->bindParam(":bairro",    $bairro);
$stmt->bindParam(":rua",       $rua);
$stmt->bindParam(":categoria", $categoria);
$stmt->bindParam(":preco",     $preco);
$stmt->bindParam(":descricao", $descricao);
$stmt->bindParam(":id",        $id);
$stmt->execute();

header("Location: listarrestaurante.php");
exit;
?>
