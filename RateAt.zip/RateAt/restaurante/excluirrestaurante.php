<?php
// RateAt — Excluir restaurante
include("../config/conexao.php");

$id = (int) $_GET["id"];

$sql  = "DELETE FROM restaurante WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->bindParam(":id", $id);

if ($stmt->execute()) {
    header("Location: listarrestaurante.php");
    exit;
} else {
    echo "Erro ao excluir restaurante.";
}
?>
