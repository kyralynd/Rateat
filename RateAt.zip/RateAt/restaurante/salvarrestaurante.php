<?php
// RateAt — Salvar novo restaurante
include("../config/conexao.php");

$nome      = $_POST["nome"];
$cep       = $_POST["cep"];
$bairro    = $_POST["bairro"];
$rua       = $_POST["rua"];
$categoria = $_POST["categoria"];
$preco     = $_POST["preco"];
$descricao = $_POST["descricao"];

$sql = "INSERT INTO restaurante (nome, cep, bairro, rua, categoria, preco, descricao)
        VALUES (:nome, :cep, :bairro, :rua, :categoria, :preco, :descricao)";

$stmt = $conn->prepare($sql);
$stmt->bindParam(":nome",      $nome);
$stmt->bindParam(":cep",       $cep);
$stmt->bindParam(":bairro",    $bairro);
$stmt->bindParam(":rua",       $rua);
$stmt->bindParam(":categoria", $categoria);
$stmt->bindParam(":preco",     $preco);
$stmt->bindParam(":descricao", $descricao);

if ($stmt->execute()) {
    echo "Restaurante cadastrado com sucesso!";
    echo '<br><a href="listarrestaurante.php">Ver lista de restaurantes</a>';
} else {
    echo "Erro ao cadastrar restaurante.";
}
?>
