<?php
include("conexao.php");

$id = $_POST["id"];
$nome = $_POST["nome"];
$email = $_POST["email"];
$senha = $_POST["senha"];

$sql = "UPDATE usuario SET
nome = '$nome', email = '$email', senha = '$senha'
WHERE usuario.id = '$id'";

$query = mysqli_query($conn, $sql);

header("Location: listarusuario.php");
?>