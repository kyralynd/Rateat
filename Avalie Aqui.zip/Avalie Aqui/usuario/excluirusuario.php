<?php
include("conexao.php");
$id = $_GET["id"];

$mysqli = new mysqli("localhost", "root", "alunolab", "dados");

$mysqli->query("SELECT * FROM usuario");

echo "Total de registros encontrados: " . $mysqli->affected_rows;

$mysqli->query("DELETE FROM usuario WHERE id = $id");
echo "<br> Total de registros excluídos: " . $mysqli->affected_rows;

$mysqli->close();
?>