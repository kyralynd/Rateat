<?php
include("conexao.php");
$id = $_GET["id"];
settype($id, "integer");

$sql = "select * from usuario where id = $id";
$query = mysqli_query($conn, $sql);
$dados = mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html>
<head><title>Atualizar Usuarios</title></head>

<body>

<form id="form1" name="form1" method="post" action="usuario.php">
    <input type="hidden" name="id" id="id" value="<?php echo $id;?>" />

    <h2>Edição de Cadastro de Usuarios</h2>

    <table>

        <tr>
            <td>Nome</td>
            <td>
                <input name="nome" type="text" value="
                <?php echo $dados["nome"];?>" 
            /></td>
        </tr>



        <tr>
            <td>E-Mail</td>
            <td>
                <input name="email" type="text" value="
                <?php echo $dados["email"];?>" 
                />
            </td>
        </tr>

        <tr>
            <td>Senha</td>
            <td>
                <input name="senha" type="text" value="
                <?php echo $dados["senha"];?>" 
                />
            </td>
        </tr>

        <tr>
            <td></td>
            <td>
                <input type="submit" name="Submit"
                value="Gravar"/>
            </td>
        </tr>

    </table>
</form>
</body>
</html>