<?php
include("conexao.php");

$sql = "SELECT * FROM usuario";
$query = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="pt-BR">
    <head>
    <meta charset="UTF-8">
    <title>Lista de Usuarios</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
<section class="secao-tabela">
    <div class="table-container">
    <table>
            <thead>
                <tr>
                <th>ID</th><th>NOME</th><th>EMAIL</th><th>SENHA</th>
                </tr>
            </thead>
        <tbody>
                <?php
                if (mysqli_num_rows($query) > 0) {
                while($L = mysqli_fetch_array($query)) {
                $id = $L["id"];
                $nome = $L["nome"];
                $email = $L["email"];
                $senha = $L["senha"];

                echo "<tr>

                <td>$id</td>
                <td>$nome</td>
                <td>$email</td>
                <td>$senha</td>

                <a href=\"editarusuario.php?id=$id\" class=\"btn-action btn-edit\">Editar</a>

                <a href=\"excluirusuario.php?id=$id\" class=\"btn-action btn-delete\">Excluir</a>

                </td>
                </tr>";
                }
                } else {
                echo "<tr><td colspan=\"10\">Nenhum usuario
                cadastrado.</td></tr>";
                }
                mysqli_close($conn);
                ?>
        </tbody>
    </table>
    </div>

</section>

</body>

</html>