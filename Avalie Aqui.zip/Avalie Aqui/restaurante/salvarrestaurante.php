<?php
include("conexao.php");

$nome = $_POST["nome"];
$cep = $_POST["cep"];
$bairro = $_POST["bairro"];
$rua = $_POST["rua"];
$categoria = $_POST["categoria"];
$descricao = $_POST["descricao"];

$result_rest = "INSERT INTO restaurante(nome, cep, bairro, rua, categoria, descricao)
VALUES ('$nome', '$cep', '$bairro', '$rua', '$categoria', '$descricao')";

$resultado_rest = mysqli_query($conn, $result_rest);

if(mysqli_affected_rows($conn) != 0){
echo "Restaurante cadastrado com sucesso";
} else {
echo "Erro ao cadastrar";
}
?>