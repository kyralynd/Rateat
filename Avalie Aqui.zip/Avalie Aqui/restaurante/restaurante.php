<?php
include("conexao.php");

$id = $_POST["id"];
$nome = $_POST["nome"];
$cep = $_POST["cep"];
$bairro = $_POST["bairro"];
$rua = $_POST["rua"];
$categoria = $_POST["categoria"];
$descricao = $_POST["descricao"];

$sql = "UPDATE restaurante SET
nome = '$nome', cep = '$cep', bairro = '$bairro', rua = '$rua', categoria = '$categoria', descricao = '$descricao'
WHERE restaurante.id = '$id'";

$query = mysqli_query($conn, $sql);

header("Location: listarrestaurante.php");
?>