<?php
include("conexao.php");
$id = $_GET["id"];
settype($id, "integer");

$sql = "select * from restaurante where id = $id";
$query = mysqli_query($conn, $sql);
$dados = mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html>
<head><title>Atualizar Restaurantes</title></head>

<body>

<form id="form1" name="form1" method="post" action="restaurante.php">
    <input type="hidden" name="id" id="id" value="<?php echo $id;?>" />

    <h2>Edição de Cadastro de Restaurantes</h2>

    <table>

        <tr>
            <td>Nome</td>
            <td>
                <input name="nome" type="text" value="
                <?php echo $dados["nome"];?>" 
            /></td>
        </tr>



        <tr>
            <td>CEP</td>
            <td>
                <input name="cep" type="text" value="
                <?php echo $dados["cep"];?>" 
                />
            </td>
        </tr>

        <tr>
            <td>Bairro</td>
            <td>
                <input name="bairro" type="text" value="
                <?php echo $dados["bairro"];?>" 
                />
            </td>
        </tr>

        <tr>
            <td>Rua</td>
            <td>
                <input name="rua" type="text" value="
                <?php echo $dados["rua"];?>" 
                />
            </td>
        </tr>

        <tr>
            <td>Categoria</td>
            <td>
                <input name="categoria" type="text" value="
                <?php echo $dados["categoria"];?>" 
                />
            </td>
        </tr>

        <tr>
            <td>Descrição</td>
            <td>
                <input name="descricao" type="text" value="
                <?php echo $dados["descricao"];?>" 
                />
            </td>
        </tr>

        <tr>
            <td></td>
            <td>
                <input type="submit" name="Submit"
                value="Gravar"/>
            </td>
        </tr>

    </table>
</form>
</body>
</html>