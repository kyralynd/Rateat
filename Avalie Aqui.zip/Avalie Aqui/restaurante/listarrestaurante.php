<?php
include("conexao.php");

$sql = "SELECT * FROM restaurante";
$query = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="pt-BR">
    <head>
    <meta charset="UTF-8">
    <title>Lista de Restaurantes</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
<section class="secao-tabela">
    <div class="table-container">
    <table>
            <thead>
                <tr>
                <th>ID</th><th>NOME</th><th>CEP</th><th>BAIRRO</th><th>RUA</th><th>CATEGORIA</th><th>DESCRICAO</th>
                </tr>
            </thead>
        <tbody>
                <?php
                if (mysqli_num_rows($query) > 0) {
                while($L = mysqli_fetch_array($query)) {
                $id = $L["id"];
                $nome = $L["nome"];
                $cep = $L["cep"];
                $bairro = $L["bairro"];
                $rua = $L["rua"];
                $categoria = $L["categoria"];
                $descricao = $L["descricao"];

                echo "<tr>

                <td>$id</td>
                <td>$nome</td>
                <td>$cep</td>
                <td>$bairro</td>
                <td>$rua</td>
                <td>$categoria</td>
                <td>$descricao</td>

                <a href=\"editarrestaurante.php?id=$id\" class=\"btn-action btn-edit\">Editar</a>

                <a href=\"excluirrestaurante.php?id=$id\" class=\"btn-action btn-delete\">Excluir</a>

                </td>
                </tr>";
                }
                } else {
                echo "<tr><td colspan=\"10\">Nenhum restaurante cadastrado.</td></tr>";
                }
                mysqli_close($conn);
                ?>
        </tbody>
    </table>
    </div>

</section>

</body>

</html>