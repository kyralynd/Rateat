<?php

include("../config/conexao.php");

$email = $_POST["email"];

$sql = "SELECT senha FROM usuario WHERE email = '$email'";
$query = mysqli_query($conn, $sql);


if(mysqli_num_rows($query) > 0){
    
    $dados = mysqli_fetch_assoc($query);
    
    echo "<h2>Recuperação de Senha</h2>";
    echo "A senha vinculada a este e-mail é: <strong>" . $dados['senha'] . "</strong><br><br>";
    echo "<a href='../login.html'>Voltar para o Login</a>";

} else {
    
    echo "Erro: E-mail não encontrado no sistema! <br><br>";
    echo "<a href='../login.html'>Voltar e tentar novamente</a>";
}
?>