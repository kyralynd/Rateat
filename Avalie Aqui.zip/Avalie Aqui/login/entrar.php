<?php

include("../config/conexao.php");


$nome = $_POST["nome"];
$senha = $_POST["senha"];
$email = $_POST["email"];


$query = "SELECT * FROM usuario WHERE nome = '$nome' AND senha = '$senha' AND email = '$email' ";
$resultado = mysqli_query($conn, $query);


if(mysqli_num_rows($resultado) > 0){
   
    header("Location: ../inicio.html");
    exit();
    
} else {
    
    echo "Usuário ou senha incorretos! <a href='../login.html'>Voltar</a>";
}
?>