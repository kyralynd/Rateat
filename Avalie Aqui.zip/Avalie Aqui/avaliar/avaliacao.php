<?php
include("conexao.php");

$id = $_POST["id"];
$nota = $_POST["nota"];
$comentario = $_POST["comentario"];

$sql = "UPDATE avaliacao SET nota = '$nota', comentario = '$comentario'
WHERE avaliacao.id = '$id'";

$query = mysqli_query($conn, $sql);

header("Location: listaravaliacoes.php");
?>