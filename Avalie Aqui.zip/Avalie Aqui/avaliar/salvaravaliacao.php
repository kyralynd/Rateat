<?php
include("conexao.php");

$nota = $_POST["nota"];
$comentario = $_POST["comentario"];

$result_aval = "INSERT INTO avaliacao(nota, comentario)
VALUES ('$nota', '$comentario')";

$resultado_aval = mysqli_query($conn, $result_aval);

if(mysqli_affected_rows($conn) != 0){
echo "Avaliação cadastrada com sucesso";
} else {
echo "Erro ao cadastrar";
}
?>