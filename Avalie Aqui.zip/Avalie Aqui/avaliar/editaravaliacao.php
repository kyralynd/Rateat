<?php
include("conexao.php");
$id = $_GET["id"];
settype($id, "integer");

$sql = "select * from avaliacao where id = $id";
$query = mysqli_query($conn, $sql);
$dados = mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html>
<head><title>Atualizar Avaliacoes</title></head>

<body>

<form id="form1" name="form1" method="post" action="avaliacao.php">
    <input type="hidden" name="id" id="id" value="<?php echo $id;?>" />

    <h2>Edição de Cadastro de Avaliacoes</h2>

    <table>

        <tr>
            <td>Nota</td>
            <td>
                <input name="nota" type="text" value="
                <?php echo $dados["nota"];?>" 
            /></td>

        <tr>
            <td>Comentário</td>
            <td>
                <input name="comentario" type="text" value="
                <?php echo $dados["comentario"];?>" 
            /></td>
        </tr>

        <tr>
            <td></td>
            <td>
                <input type="submit" name="Submit"
                value="Gravar"/>
            </td>
        </tr>

    </table>
</form>
</body>
</html>