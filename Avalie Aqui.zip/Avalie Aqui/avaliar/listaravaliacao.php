<?php
include("conexao.php");

$sql = "SELECT * FROM avaliacao";
$query = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="pt-BR">
    <head>
    <meta charset="UTF-8">
    <title>Lista de Avaliacoes</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
<section class="secao-tabela">
    <div class="table-container">
    <table>
            <thead>
                <tr>
                <th>ID</th><th>NOTA</th><th>COMENTARIO</th><th>DATA</th>
                </tr>
            </thead>
        <tbody>
                <?php
                if (mysqli_num_rows($query) > 0) {
                while($L = mysqli_fetch_array($query)) {
                $id = $L["id"];
                $nota = $L["nota"];
                $comentario = $L["comentario"];
                $data = $L["data"];

                echo "<tr>

                <td>$id</td>
                <td>$nota</td>
                <td>$comentario</td>
                <td>$data</td>

                <a href=\"editaravaliacao.php?id=$id\" class=\"btn-action btn-edit\">Editar</a>

                <a href=\"excluiravaliacao.php?id=$id\" class=\"btn-action btn-delete\">Excluir</a>

                </td>
                </tr>";
                }
                } else {
                echo "<tr><td colspan=\"10\">Nenhuma avaliacao
                cadastrada.</td></tr>";
                }
                mysqli_close($conn);
                ?>
        </tbody>
    </table>
    </div>

</section>

</body>

</html>